#include <bareio.h>
#include <barelib.h>


/*
 * 'builtin_hello' prints "Hello, <text>!\n" where <text> is the contents 
 * following "builtin_hello " in the argument and returns 0.  
 * If no text exists, print and error and return 1 instead.
 */
char builtin_hello(char *arg) {
    // Check if the argument only contains the text "hello"
    if (strcmp(arg, "hello") == 0) {
        printf("Error - bad argument\n");
        return 1;  // Return 1 to indicate an error
    } else {
        // Print a greeting with the remaining text after "hello"
        printf("Hello, ");
        printf(arg + 6);  // Skip the "hello" part
        printf("!\n");
        return 0;  // Return 0 to indicate success
    }
}
