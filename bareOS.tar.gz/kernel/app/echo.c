#include <bareio.h>
#include <barelib.h>


/*
 * 'builtin_echo' reads in a line of text from the UART
 * and prints it.  It will continue to do this until the
 * line read from the UART is empty (indicated with a \n
 * followed immediately by another \n).
 */
char builtin_echo(char* arg) {
    if (strcmp(arg, "echo") == 0) {
        // Loop to read characters until '\n' is received
        int character_count = 0;
        char resp[1024];
        while (1) {
            char c = uart_getc();
            if (c == '\n') {
                // End of line, print newline and return the number of characters read
                resp[character_count] = '\n';
                resp[character_count+1] = '\0';
                printf(resp);
                return character_count;
            }
            // Echo the character back to the screen
            resp[character_count] = c;
            character_count++;
        }

        
    } else {
        // Print the remaining text after "echo"
        printf(arg + 5);  // Skip the "echo" part
        printf("\n");
        return 0;  // Return 0 to indicate success
    }
}
