#include <bareio.h>
#include <barelib.h>
#include <thread.h>

#define PROMPT "bareOS$ "  /*  Prompt printed by the shell to the user  */

unsigned char previous_return_value = 0;
char shell(char* args) {
  while(1){
    char query[1025];
    char command[1025];
    unsigned char command_result;
    while(1){

      printf(PROMPT);
        // Read characters until '\n' is received or buffer is full
        int i = 0;
        while (1) {
            char c = uart_getc();
            if (c == '\n' || c == '\0' || i >= 1024) {
                query[i] = '\0';  // Null terminate the input
                break;
            }
            if(c == '?' && i > 0 && query[i-1] =='$'){
              query[i-1] = '0' + previous_return_value;
              continue;
            }
            query[i++] = c;
        }
        
        int space_index = 0;
        
        while (query[space_index] != ' ' && query[space_index] != '\0') {
            space_index++;
        }
        int j=0;
        for(j=0;j<space_index;j++)command[j] = query[j];
        command[j]='\0';
        // for(j=0;j<=space_index;j++)
        // uart_putc(command[j]);
        // printf("\n");
        // printf(query);
        // printf("\n");
        if (strcmp(command, "hello") == 0) {
              uint32 tid = create_thread(&builtin_hello, query, i);
              resume_thread(tid);
           command_result = join_thread(tid);
      
        }else if(strcmp(command, "echo") == 0){
              uint32 tid = create_thread(&builtin_echo, query, i);
              resume_thread(tid);
           command_result = join_thread(tid);
        }else {
            printf("Unknown command\n");
            command_result = 255;
  
        }

    previous_return_value = command_result;

    }
  }
  return 0;
}
