#include <barelib.h>
#include <syscall.h>
#include <thread.h>
#include <interrupts.h>
#include <queue.h>
#include <bareio.h>
/*  'resched' places the current running thread into the ready state  *
 *  and  places it onto  the tail of the  ready queue.  Then it gets  *
 *  the head  of the ready  queue  and sets this  new thread  as the  *
 *  'current_thread'.  Finally,  'resched' uses 'ctxsw' to swap from  *
 *  the old thread to the new thread.                                 */
int32 resched(void) {
  // printf("resched here, current thread %d", current_thread);
  uint32 start_idx = current_thread;
//   while(thread_table[current_thread].state!=TH_READY){
//     current_thread++;
//     current_thread%=NTHREADS;
//     if(current_thread == start_idx)
// return 0;   
//     }       
  uint32 id = thread_dequeue(ready_list);
 
  if (id == (uint32)NTHREADS)return 0;          
  //  printf("got id as %d, current thread %d \n", id, start_idx);
  // return 0;
  char mask;

  mask = disable_interrupts();
  if(thread_table[start_idx].state == TH_READY || thread_table[start_idx].state == TH_RUNNING){
thread_table[start_idx].state = TH_READY;
// thread_enqueue(ready_list, current_thread);
  }
  
  thread_table[id].state = TH_RUNNING;
// printf("reached here, just before context switch \n");
thread_enqueue(ready_list, current_thread);
current_thread = id;
  ctxsw(&thread_table[id].stackptr, &thread_table[start_idx].stackptr);
  
  restore_interrupts(mask);

  //  printf("got id as %d", id);
  
  return 0;
}

