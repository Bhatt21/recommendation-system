#include <queue.h>
#include <bareio.h>
/*  Queues in bareOS are all contained in the 'thread_queue' array.  Each queue has a "root"
 *  that contains the index of the first and last elements in that respective queue.  These
 *  roots are  found at the end  of the 'thread_queue'  array.  Following the 'qnext' index 
 *  of each element, starting at the "root" should always eventually lead back to the "root".
 *  The same should be true in reverse using 'qprev'.                                          */

queue_t thread_queue[NTHREADS+2];   /*  Array of queue elements, one per thread plus one for the read_queue root  */
uint32 ready_list = NTHREADS + 0;
uint32 sleep_list = NTHREADS + 1;   /*  Index of the read_list root  */


/*  'thread_enqueue' takes an index into the thread_queue  associated with a queue "root"  *
 *  and a threadid of a thread to add to the queue.  The thread will be added to the tail  *
 *  of the queue,  ensuring that the  previous tail of the queue is correctly threaded to  *
 *  maintain the queue.                                                                    */
void thread_enqueue(uint32 queue, uint32 threadid) {
  
  // if(thread_queue[queue].qnext == thread_queue[queue].qprev){
  //   thread_queue[queue].qnext = thread_queue[queue].qprev = threadid;
  //   thread_queue[threadid].qnext = thread_queue[threadid].qprev = queue;
  //   thread_queue[threadid].key = thread_table[threadid].priority;
  //   //     printf("\n queue %d: %d: %d", thread_queue[queue].qprev, thread_queue[queue].qnext, thread_queue[queue].key);
  //   // printf("\n new %d: %d: %d", thread_queue[threadid].qprev, thread_queue[threadid].qnext, thread_queue[threadid].key);
  //   // return;
    
  // }
  uint32 curr = thread_queue[queue].qnext;
  uint16 found = 0;
  while (curr != queue)
  {
    if(curr == threadid){
      found = 1;
      break;
    }
    curr = thread_queue[curr].qnext;
  }
  if(found){
    return;}
  uint32 prev = 0;
  
  curr = thread_queue[queue].qnext;
  while(curr != queue){
    thread_queue[curr].key = thread_table[curr].priority;
    curr = thread_queue[curr].qnext;
  }
  curr = thread_queue[queue].qnext;
  uint32 placed = 0;
  // uint32 carry = 0;
  while(curr != queue){
      // printf("ok");
    if(thread_queue[curr].key > thread_table[threadid].priority){

        uint32 curr_prev = thread_queue[curr].qprev;
        thread_queue[curr].qprev = threadid;
        thread_queue[curr_prev].qnext = threadid;
        thread_queue[threadid].qprev = curr_prev;
        thread_queue[threadid].qnext = curr;
        
        thread_queue[threadid].key = thread_table[threadid].priority;
        placed = 1;
        break;
    }
     curr = thread_queue[curr].qnext;
  }
  if(!placed){
    uint32 cur_prev = thread_queue[queue].qprev;
    thread_queue[queue].qprev = threadid;
    thread_queue[cur_prev].qnext = threadid;
    thread_queue[threadid].qprev = cur_prev;
    thread_queue[threadid].qnext = queue;

    thread_queue[threadid].key = thread_table[threadid].priority;
  }
  curr = thread_queue[queue].qnext;
    while(curr != queue){
    thread_queue[curr].key = thread_table[curr].priority-prev;
    prev = thread_table[curr].priority;
    curr = thread_queue[curr].qnext;
  }


    //     printf("\n queue %d: %d: %d", thread_queue[queue].qprev, thread_queue[queue].qnext, thread_queue[queue].key);
    // printf("\n new %d: %d: %d", thread_queue[threadid].qprev, thread_queue[threadid].qnext, thread_queue[threadid].key);
  
  // to do if the thread id is the smallest!

  return;
}


/*  'thread_dequeue' takes a queue index associated with a queue "root" and removes the  *
 *  thread at the head of the queue and returns the index of that thread, ensuring that  *
 *  the queue  maintains its structure and the head correctly points to the next thread  *
 *  (if any).                                                                            */
uint32 thread_dequeue(uint32 queue) {
  if(thread_queue[queue].qnext == queue)return NTHREADS;
  else {
    uint32 id = thread_queue[queue].qnext;
    uint32 nextid = thread_queue[id].qnext;
    thread_queue[queue].qnext = thread_queue[id].qnext;
    thread_queue[nextid].qprev = queue;

  uint32 curr = thread_queue[queue].qnext;

  while(curr != queue){
    thread_queue[curr].key = thread_table[curr].priority;
    curr = thread_queue[curr].qnext;
  }
  curr = thread_queue[queue].qnext;
  uint32 prev = 0;
    while(curr != queue){
    thread_queue[curr].key = thread_table[curr].priority-prev;
    prev = thread_table[curr].priority;
    curr = thread_queue[curr].qnext;
  }  
    return id;
  }
}
