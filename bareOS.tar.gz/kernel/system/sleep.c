#include <barelib.h>
#include <interrupts.h>
#include <syscall.h>
#include <thread.h>
#include <queue.h>



/*  Places the thread into a sleep state and inserts it into the  *
 *  sleep delta list.                                             */
int32 sleep(uint32 threadid, uint32 delay) {
  if(!delay){
    raise_syscall(RESCHED);
    return 0;
  }
  char mask;
  mask = disable_interrupts();
  uint32 id = thread_dequeue(ready_list);
  if(id != NTHREADS && id != threadid){
    thread_enqueue(ready_list, id);
  }
  thread_table[threadid].state = TH_SLEEP;
  thread_table[threadid].priority = delay;
  thread_enqueue(sleep_list, threadid);
  restore_interrupts(mask);
  return 0;
}

/*  If the thread is in the sleep state, remove the thread from the  *
 *  sleep queue and resumes it.                                      */
int32 unsleep(uint32 threadid) {
  char mask;
  mask = disable_interrupts();
  if(thread_table[threadid].state != TH_SLEEP)return -1;
  
  uint32 id = thread_dequeue(sleep_list);
  if(id != threadid){
     uint32 newid = thread_dequeue(sleep_list);
    thread_enqueue(sleep_list, id);
    id = newid;
   
    
  }
  thread_enqueue(ready_list, id);
  raise_syscall(RESCHED);
  restore_interrupts(mask);
  return 0;
}
