#include <barelib.h>
#include <thread.h>
#include <interrupts.h>
#include <syscall.h>
#include <queue.h>


/*  Takes an index into the thread_table.  If the thread is TH_DEFUNCT,  *
 *  mark  the thread  as TH_FREE  and return its  `retval`.   Otherwise  *
 *  raise RESCHED and loop to check again later.                         */
byte join_thread(uint32 threadid) {
  if(thread_table[threadid].state == TH_FREE){
    return -1;
  }
  // printf("\njoin here thread id as %d\n", threadid);
  while(thread_table[threadid].state != TH_DEFUNCT){
    raise_syscall(RESCHED);
    // printf("\nno fkin way\n");
    
  }
  // printf("hum jeet gaye");
  

  char mask;
  mask = disable_interrupts();
  thread_table[threadid].state = TH_FREE;
  restore_interrupts(mask);
  return thread_table[threadid].retval;
}
