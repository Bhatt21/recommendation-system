#include <barelib.h>
#include <fs.h>

/* fs_write - Takes a file descriptor index into the 'oft', a  pointer to a  *
 *            buffer  that the  function reads data  from and the number of  *
 *            bytes to copy from the buffer to the file.                     *
 *                                                                           *
 *            'fs_write' reads data from the 'buff' and copies it into the   *
 *            file  'blocks' starting  at the 'head'.  The  function  will   *
 *            allocate new blocks from the block device as needed to write   *
 *            data to the file and assign them to the file's inode.          *
 *                                                                           *
 *  returns - 'fs_write' should return the number of bytes written to the    *
 *            file.                                
                           */
extern filetable_t oft[NUM_FD];
extern fsystem_t* fsd;
static uint32 max(uint32 a, uint32 b){
  if(a>=b)return a;
  return b;
}
static uint32 min(uint32 a, uint32 b){
  if(a<b)return a;
  return b;
}
uint32 fs_write(uint32 fd, char* buff, uint32 len) {
  inode_t inode = oft[fd].inode;
  uint32 currhead = oft[fd].head;
  uint32 blockused = currhead/MDEV_BLOCK_SIZE;
  uint32 curr_block = blockused;
  if(inode.blocks[blockused] < MDEV_BLOCK_SIZE)
    curr_block = inode.blocks[blockused];
  else {
    for(int j=2;j<fsd->device.nblocks;j++){
      if(!fs_getmaskbit(j)){
        fs_setmaskbit(j);
        curr_block = j;
        inode.blocks[blockused]=j;
        break;
      }
    }
  }

    inode.size = max(len,inode.size);
    uint32 spaceleftthisblock = MDEV_BLOCK_SIZE-currhead%MDEV_BLOCK_SIZE;
    bs_write(curr_block, currhead%MDEV_BLOCK_SIZE, buff, min(spaceleftthisblock, len));
    buff += min(spaceleftthisblock, len);
    uint32 remaining = 0;
    if(len<= spaceleftthisblock)remaining = 0;
    else remaining = len-spaceleftthisblock;
    // if(!remaining)return -1;
    uint32 blocksfilled = 1+blockused;
    uint32 blocksneeded = remaining/MDEV_BLOCK_SIZE + (remaining%MDEV_BLOCK_SIZE?1:0);
    if((blocksneeded+blocksfilled)>INODE_BLOCKS)return -1;
    for(int i=blocksfilled;i<blocksfilled+blocksneeded;i++){
      for(int j=2;j<fsd->device.nblocks && remaining>0;j++){
        uint32 newblock = inode.blocks[i];
        if(inode.blocks[i] >= MDEV_BLOCK_SIZE){
          if(fs_getmaskbit(j))continue;
          fs_setmaskbit(j);
          newblock = j;
        }
          inode.blocks[i]=newblock;
          if(remaining > MDEV_BLOCK_SIZE){
            bs_write(newblock,0,buff,MDEV_BLOCK_SIZE);
            remaining -= MDEV_BLOCK_SIZE;
            buff += MDEV_BLOCK_SIZE;
          }else{
            bs_write(newblock,0,buff,remaining);
            buff += remaining;
            remaining = 0;
          }
        
      }
    }
    if(remaining)return -1;
    oft[fd].head += len;
    inode.size = max(inode.size, oft[fd].head);
    bs_write(inode.id,0,&inode,sizeof(inode));
    oft[fd].inode = inode;
    return 0;
  

  }

    // bs_write(inode.id,0,&inode,sizeof(inode_t));


