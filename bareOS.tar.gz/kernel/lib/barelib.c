
#include <barelib.h>

void* mymemset(void* s, int c, int n) {
  while (n-- >= 0) ((char*)s)[n] = (char)c;
  return s;
}

void* memcopy(void* dst, const void* src, int n) {
  while (n >= 0) {((char*)dst)[n] = ((char*)src)[n];n--;}
  return dst;
}

int strcmp(const char *str1, const char *str2) {
    while (*str1 && (*str1 == *str2)) {
        str1++;
        str2++;
    }
    return *(unsigned char *)str1 - *(unsigned char *)str2;
}