#include <barelib.h>
#include <fs.h>

extern fsystem_t* fsd;
static int t__strcmp(char* a, char* b) {
  int i;
  for (i=0; a[i] == b[i] && a[i] != '\0' && b[i] !='\0'; i++);
  return a[i] != b[i];
}
/*  Search for 'filename' in the root directory.  If the  *
 *  file exists,  returns an error.  Otherwise, create a  *
 *  new file  entry in the  root directory, a llocate an  *
 *  unused  block in the block  device and  assign it to  *
 *  the new file.                                         */
int32 fs_create(char* filename) {

  if(fsd->root_dir.numentries == DIR_SIZE)return -1;
  for(uint32 i=0;i<DIR_SIZE;i++){

      if(!t__strcmp(fsd->root_dir.entry[i].name, filename))return -1;
    
  }

uint32 i = fsd->root_dir.numentries;
    for(int j=2;j<fsd->device.nblocks;j++){
        if(!fs_getmaskbit(j)){
          fs_setmaskbit(j);
          fsd->root_dir.entry[i].inode_block = j;
          uint32 idx = 0;
          while(filename[idx]!='\0'){
            fsd->root_dir.entry[i].name[idx]=filename[idx];
            idx+=1;
          }
          fsd->root_dir.entry[i].name[idx]='\0';    
          fsd->root_dir.numentries+=1;  
          fsd->freemasksz+=1;
          inode_t inode;
          inode.id = j;
          inode.size = 0;
          bs_write(j,0,&inode,sizeof(inode_t));
          bs_write(SB_BIT, 0, fsd, sizeof(fsystem_t));           /*  block  as used  and write  the 'fsd'  and  */
          bs_write(BM_BIT, 0, fsd->freemask, fsd->freemasksz);     
          return 0;    
        }

      // fs_print_mask();
    
  }
  return -1;  

}
