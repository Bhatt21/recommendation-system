#include <barelib.h>
#include <fs.h>

extern fsystem_t* fsd;
extern filetable_t oft[NUM_FD];
static int t__strcmp(char* a, char* b) {
  int i;
  for (i=0; a[i] == b[i] && a[i] != '\0' && b[i] !='\0'; i++);
  return a[i] != b[i];
}
/*  Search for a filename  in the directory, if the file doesn't exist  *
 *  or it is  already  open, return  an error.   Otherwise find a free  *
 *  slot in the open file table and initialize it to the corresponding  *
 *  inode in the root directory.                                        *
 *  'head' is initialized to the start of the file.                     */
int32 fs_open(char* filename) {
  uint32 exist=0;
  for(uint32 i=0;i<DIR_SIZE;i++){

      if(!t__strcmp(fsd->root_dir.entry[i].name, filename))exist=1;
    
  }
  if(!exist)return -1;
  uint32 inode_val=-1;
  uint32 fileidx=-1;
  
  for(int i=0;i<NUM_FD;i++){
    if(!t__strcmp(filename, fsd->root_dir.entry[oft[i].direntry].name)){
      if(oft[i].state == FSTATE_OPEN){
        return -1;
      }
    }
  }
  for(uint32 i=0;i<DIR_SIZE;i++){
      if(!t__strcmp(fsd->root_dir.entry[i].name, filename)){
        inode_val=fsd->root_dir.entry[i].inode_block;
        fileidx = i;
        }
  }
  inode_t inode;
  bs_read(inode_val, 0, &inode, sizeof(inode_t));
   for(int i=0;i<NUM_FD;i++){
    if(oft[i].state == FSTATE_CLOSED){
      oft[i].state = FSTATE_OPEN;
      oft[i].direntry = fileidx;
      oft[i].inode = inode;
      return i;
    }
   }
   return -1;




  return 0;
}
