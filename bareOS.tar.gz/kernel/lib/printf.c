#include <barelib.h>
#include <bareio.h>
void reverse(char str[], int length) {
    int start = 0;
    int end = length - 1;
    while (start < end) {
        char temp = str[start];
        str[start] = str[end];
        str[end] = temp;
        start++;
        end--;
    }
}

// Convert integer to string
void itoa(uint32 num, char str[], int base) {
    int i = 0;
    int isNegative = 0;
    if (num == 0) {
        str[i++] = '0';
        str[i] = '\0';
        return ;
    }
    if (num < 0 && base == 10) {
        isNegative = 1;
        num = -num;
    }
    while (num != 0) {
        uint32 rem = num % base;
        str[i++] = (rem > 9) ? (rem - 10) + 'a' : rem + '0';
        num = num / base;
    }
    if (isNegative && base == 10)
        str[i++] = '-';

    str[i] = '\0'; // Null-terminate string

    // Reverse the string
    reverse(str, i);
    return ;
}
void uart_puts(const char *str) {
    while (*str != '\0') {
        uart_putc(*str);
        str++;
    }
}


void printf(const char* template, ...) {
    va_list args;
    va_start(args, template);

    while (*template != '\0') {
        if (*template == '%') {
            template++;
            switch (*template) {
                case 'd':
                    {
                        // template ++;
                        uint32 value = va_arg(args, uint32);
                        char buffer[20];
                        itoa(value, buffer, 10);
                        uart_puts(buffer);
                        break;
                    }
                case 'x':
                    {
                        // template ++;
                        uint32 value = va_arg(args, uint32);
                        char buffer[20];
                        uart_putc('0');
                        uart_putc('x');
                        itoa(value, buffer, 16);
                        uart_puts(buffer);
                        break;
                    }
                default:
                    uart_putc(*template);
                    break;
            }
        } else {
            uart_putc(*template);
        }

        template++;
    }

    va_end(args);
}
